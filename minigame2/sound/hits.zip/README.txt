Adapted from Punch, slap, n' kick.wav
by CGEffex
http://freesound.org/people/CGEffex/sounds/98341/
http://creativecommons.org/licenses/by/3.0/